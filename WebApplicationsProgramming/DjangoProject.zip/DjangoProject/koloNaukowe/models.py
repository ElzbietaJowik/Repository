from django.db import models

# Create your models here.
class Zgloszenie(models.Model):
    Omnie = models.CharField(max_length=127)
    imie = models.TextField()
    nazwisko = models.TextField()
    pub_date = models.DateTimeField('date published')

    def __str__(self):
        return self.Omnie, self.imie, self.nazwisko, self.pub_date
