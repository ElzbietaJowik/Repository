from django import forms
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError

class RegistrationForm(forms.Form):
    error_css_class = "error"

    imie = forms.CharField(label="Imię", max_length=25, validators=[
        RegexValidator(r'^[a-zA-Z]+$', message="Imię tylko angielskimi literami!")])
    nazwisko = forms.CharField(label="Nazwisko", max_length=25, validators=[
        RegexValidator(r'^[a-zA-Z]+$', message="Nazwisko tylko angielskimi literami!")])
    Omnie = forms.CharField(label="O mnie", max_length=300, widget=forms.Textarea, required=False)


    def clean(self):
        n = len(self.data['Omnie'])
        if not n % 4 == 0:
            raise ValidationError('Suma znaków nie jest podzielna przez 3')

    def clean_imie(self):
        return self.cleaned_data['imie'].capitalize()

    def clean_nazwisko(self):
        return self.cleaned_data['nazwisko'].capitalize()