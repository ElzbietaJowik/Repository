from django.shortcuts import render
from django.utils import timezone

from .forms import RegistrationForm
from .models import Zgloszenie
from django.http import HttpResponseRedirect


# Create your views here.

def index(request):
    return render(request, 'koloNaukowe/index.html')

def rejestracja(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            c = Zgloszenie(Omnie=form.cleaned_data['Omnie'],
                           imie=form.cleaned_data['imie'],
                           nazwisko=form.cleaned_data["nazwisko"],
                            pub_date=timezone.now())
            c.save()
            form = RegistrationForm()
    else:
        form = RegistrationForm()
    context = {'form': form}
    return render(request, 'koloNaukowe/rejestracja.html', context = context)

def lista_czlonkow(request):
    zgloszenia = Zgloszenie.objects.order_by('-pub_date')
    context = {'zgloszenia': zgloszenia}
    return render(request, 'koloNaukowe/lista_czlonkow.html', context = context)