from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('rejestracja', views.rejestracja, name='rejestracja'),
    path('lista_czlonkow', views.lista_czlonkow, name='lista_czlonkow'),
]
