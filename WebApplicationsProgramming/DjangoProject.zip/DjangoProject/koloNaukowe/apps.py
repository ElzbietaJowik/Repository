from django.apps import AppConfig


class KolonaukoweConfig(AppConfig):
    name = 'koloNaukowe'
