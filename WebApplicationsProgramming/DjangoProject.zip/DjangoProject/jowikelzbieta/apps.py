from django.apps import AppConfig


class JowikelzbietaConfig(AppConfig):
    name = 'jowikelzbieta'
